class AppFontSize{
  static const double fs5 = 5.0;
  static const double fs10 = 10.0;
  static const double fs12 = 12.0;
  static const double fs14 = 14.0;
  static const double fs15 = 15.0;
  static const double fs17 = 17.0;
  static const double fs18 = 18.0;
  static const double fs20 = 20.0;
  static const double fs24 = 24.0;
  static const double fs28 = 28.0;
  static const double fs32 = 32.0;
}
