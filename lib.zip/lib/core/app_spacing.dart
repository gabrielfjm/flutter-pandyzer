class AppSpacing {
  static const double small = 5.0;
  static const double normal = 10.0;
  static const double medium = 15.0;
  static const double big = 20.0;
  static const double giant = 40.0;
}